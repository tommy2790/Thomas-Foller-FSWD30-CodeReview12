<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="<?php bloginfo('description'); ?>">
    <title>
        <?php bloginfo('name'); ?> |
        <?php is_front_page() ? bloginfo('description') : wp_title(); ?>
    </title>
    <!-- Bootstrap core CSS -->
    <link href="<?php bloginfo('template_url'); ?>/css/bootstrap.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
    <?php wp_head(); ?>
    <style>
        .showcase {
            background: url(<?php echo get_theme_mod('showcase_image', get_bloginfo('template_url').'/img/showcase.jpg');
            ?>) no-repeat center center;
        }

    </style>
</head>

<body>
    <div class="blog-masthead">
        <div class="container">
            <nav class="blog-nav">
                <?php
           wp_nav_menu( array(
               'menu'              => 'primary',
               'theme_location'    => 'primary',
               'depth'             => 2,
               'container'         => 'div',
               'container_class'   => 'collapse navbar-collapse',
       'container_id'      => 'bs-example-navbar-collapse-1',
               'menu_class'        => 'nav navbar-nav',
               'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
               'walker'            => new wp_bootstrap_navwalker())
           );
       ?>
            </nav>
        </div>
    </div>

    <section class="showcase">
        <div class="container">
            <h1>Mount Everest Travel Agency</h1>
            <p>We provide unique experiences for young travellers</p>
            <a href="<?php echo get_theme_mod('btn_url', 'http://test.com'); ?>" class="btn btn-primary btn-lg">
                <?php echo get_theme_mod('btn_text', 'Learn more'); ?>
            </a>
        </div>
    </section>

    <section class="boxes">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="box">
                        <i class="fa fa-comment" aria-hidden="true"></i>
                        <h3>Lorem ipsum Dolor</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi, voluptatem?</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="box">
                        <i class="fa fa-heart aria-hidden=" true "></i>
              <h3>Lorem ipsum Dolor</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi, voluptatem?</p>
            </div>
          </div>
          <div class="col-md-4 ">
            <div class="box ">
              <i class="fa fa-question " aria-hidden="true "></i>
              <h3>Lorem ipsum Dolor</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi, voluptatem?</p>
            </div>
          </div>
        </div>
    </section>

<footer class="blog-footer ">
  <p>&copy; <?php echo Date('Y'); ?> - <?php bloginfo('name'); ?></p>
  <p>
    <a href="# ">Back to top</a>
  </p>
</footer>
<?php wp_footer(); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js "></script>
<script src="<?php bloginfo( 'template_url'); ?>/js/bootstrap.js"></script>
</body>

</html>
